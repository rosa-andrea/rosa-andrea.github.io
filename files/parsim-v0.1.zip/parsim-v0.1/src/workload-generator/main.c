/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * main.c
 * Copyright (C) 2013-2014 Andrea Rosà <andrea.rosa@usi.ch>
	 * 
 * workload-generator is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
	 * 
 * workload-generator is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


/*  Parameters of main function:
 *	 argv[1]: 1 if there's the need to generate new matrices, 0 otherwhise. 	 
	 */

#include "types.h" 
#include "mt64.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h> 
#include <math.h>
#include <linux/sched.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>


PointerToPIDsLookupTabel pidLookup; 

PointerToIDsLookupTabel idLookupTabel;

PointerToArgumentTabel argumentTabel; 

int numberOfThreads, numberOfPhases;

double computeExtendedTime(struct timespec time) {

	return (double) time.tv_sec * (double) 1000 + (double) ( (double) time.tv_nsec / (double) 1000000 );
}

pointerToElements initializeElementsStructures(int rows,int columns,Boolean type) {
	long int var1, var2, var3;
	double min,max;

	if (!type) {
		var1 = rows;
		var2 = columns;

	} else {
		var1 = columns;
		var2 = rows;
	}

	pointerToElements root = (pointerToElements) malloc(sizeof(void*)*var1);
	int i,j;
	for (i = 0;i < var1; i++) {
		(*root)[i] = malloc(sizeof(Element));
		pointerToElement current = (*root)[i];
		for (j = 0; j<var2; j++) {
			min = (MAX_MINRANDOM-MIN_MINRANDOM)*genrand64_real1() + MIN_MINRANDOM;
			max = (MAX_MAXRANDOM-MIN_MAXRANDOM)*genrand64_real1() + MIN_MAXRANDOM;
			current->value = (max-min)*genrand64_real1() + min; //Initial value, not valid.
			current->valid = false;
			current->position = j;
			if (j != var2-1) 
				current->next = malloc(sizeof(Element));
			current = current->next;
		}
	}



	//Test print
	if (DEBUG_FLAG==1) {
		printf("------------------------------------- ._. --------------------------------- \n");
		for (i = 0;i < var1; i++) {
			pointerToElement current = (*root)[i];
			for (j = 0; j<var2; j++) {
				printf("%lf ",current->value);
				current = current->next;
			}
			printf("\n");
		}
	}

	return root;

}

int determineSize(PhaseType type) {
	if (type == IO || type == CPU)
		return sizeof(OrdinaryPhase);
	else if (type == LOOP)
		return sizeof(LoopPhase);
	else if (type == FORK)
		return sizeof(ForkPhase);
	else if (type == JOIN)
		return sizeof(JoinPhase);

}


void createMatricesAndElementsStructures(int genMatrix) {

	int i,result;
	init_genrand64((unsigned long long) time(NULL)); 

	for (i = 0; i < numberOfThreads; i++) {

		ThreadUtilities * tu = malloc(sizeof(ThreadUtilities));

		char iString[INDEX_LENGTH]; 
		sprintf(iString,"%d",i);

		char pathnameA[PATHNAME_LENGTH] = A_PATHNAME;
		strcat(pathnameA, iString);

		char pathnameB[PATHNAME_LENGTH] = B_PATHNAME;
		strcat(pathnameB, iString);

		char pathnameC[PATHNAME_LENGTH] = C_PATHNAME;
		strcat(pathnameC, iString);

		char pathnameStat[PATHNAME_LENGTH] = STAT_PATHNAME;
		strcat(pathnameStat, iString);

		char pathnameLog[PATHNAME_LENGTH] = LOG_PATHNAME;
		strcat(pathnameLog, iString);

		char mString[DIMENSIONS_LENGTH];
		char pString[DIMENSIONS_LENGTH];
		char nString[DIMENSIONS_LENGTH];
		char minString[NUMBER_LENGTH];
		char maxString[NUMBER_LENGTH];

		if (genMatrix ==1) {

			tu->m = ceil((MAX_M-MIN_M)*genrand64_real1() + MIN_M);
			tu->p = ceil((MAX_P-MIN_P)*genrand64_real1() + MIN_P);
			tu->n = ceil((MAX_N-MIN_N)*genrand64_real1() + MIN_N);

			sprintf(mString,"%d",tu->m);

			sprintf(pString,"%d",tu->p);

			sprintf(nString,"%d",tu->n);

			if (DEBUG_FLAG==1) {
				printf("i: %s m: %s n: %s p: %s\n",iString,mString,nString,pString);
			}
			double minNumber = (MAX_MINRANDOM-MIN_MINRANDOM)*genrand64_real1() + MIN_MINRANDOM;
			sprintf(minString,"%lf",minNumber);

			double maxNumber = (MAX_MAXRANDOM-MIN_MAXRANDOM)*genrand64_real1() + MIN_MAXRANDOM;
			sprintf(maxString,"%lf",maxNumber);

			if (DEBUG_FLAG==1) {

				printf("min random number: %s, max random number: %s\n", minString, maxString);
			}
		}

		pid_t pid;
		char * arglist[] = {"matrices_generator", pathnameA, pathnameB, mString, pString, nString, minString, maxString, NULL} ;
		
		if (genMatrix == 1)  pid = fork (); 

		else 
			pid = getpid(); 

		if (pid == 0)
			/* This is the child process.  */
		{
			execve ("matrices_generator", arglist, NULL);
			printf ("Error in EXECVE!! This point should be unreachable!! %d...\n", errno);
			exit(-1);
		}	
		else {
			//This is the father
			if (genMatrix == 1)
				wait(NULL);
			tu->fileA = open(pathnameA,O_RDWR); 
			tu->fileB = open(pathnameB,O_RDWR); 

			double *t = malloc(sizeof(double));

			if (genMatrix == 1) {	


				*t = tu->n;


				//Initialize C and fill it with NaN
				tu->fileC = open(pathnameC,O_WRONLY|O_TRUNC|O_CREAT,0666);

				result = write(tu->fileC,t,sizeof(double)); //Write in fileC the number of columns of result matrix (n)

				if (result != sizeof(double)) {
					printf("Error while writing to disk - Initialization phase. - Write size differs from double size \n");
					exit(-1);
				}	

				*t = NAN;
				int row,column;

				for(row=0;row<tu->m;row++)
					for(column=0;column<tu->n;column++) {
						result = write(tu->fileC,t,sizeof(double));
						if (result != sizeof(double)) {
							printf("Error while writing to disk - Initialization phase. - Write size differs from double size \n");
							exit(-1);
						}
					}

			}

			else {
				tu->fileC = open(pathnameC,O_WRONLY);
				long int sizeA = (long int)lseek(tu->fileA, 0, SEEK_END); //Size of A.mat in bytes
				lseek(tu->fileA,0, SEEK_SET);
				read(tu->fileA,(double *)t,sizeof(double));
				tu->p = floor(*t); //The ceiling functions are added just for safety, but they shouldn't be necessary.
				tu->m = floor((sizeA - sizeof(double))/((tu->p)*sizeof(double)));
				read(tu->fileB,(double *)t,sizeof(double));
				tu->n = floor(*t);
			}


			(*argumentTabel)[i].arg = tu;
			if (DEBUG_FLAG==1) {
				printf("Initial Address: %x , tu: %x in Argument Table entry %d\n", (*argumentTabel)[i].initialAddress, (*argumentTabel)[i].arg,  i);
			}

			tu->rootA = initializeElementsStructures(tu->m,tu->p,false);
			tu->rootB = initializeElementsStructures(tu->p,tu->n,true);
			tu->rootC = initializeElementsStructures(tu->m,tu->n,false);

			tu->initialStat = malloc(sizeof(Statistics));	
			tu->currentStat = tu->initialStat;	

			tu->statFile = open(pathnameStat,O_WRONLY|O_TRUNC|O_CREAT,0666);
			tu->logFile = open(pathnameLog,O_RDWR|O_TRUNC|O_CREAT,0666);

		}

	}

}

void * setIOPhase(PointerToIDsLookupTabel tabel, int *index, void *current, int id, ValueType unit, long int value, PhaseType nextType) {

	OrdinaryPhase *pointer = (OrdinaryPhase *) current;
	pointer->type = IO;
	pointer->id = id;
	pointer->unit = unit;
	pointer->value = value;
	if (nextType != EMPTY)
		pointer->next = malloc(determineSize(nextType));
	else
		pointer->next = NULL;

	(*idLookupTabel)[*index].id = id;
	(*idLookupTabel)[*index].address = pointer;
	(*index)++;

	if (DEBUG_FLAG==1) {
		printf("New current: %x - Next: %x\n",pointer, pointer->next);
	}


	return pointer->next;

}

void * setCPUPhase(PointerToIDsLookupTabel tabel, int *index, void *current, int id, ValueType unit, long int value, PhaseType nextType) {


	OrdinaryPhase *pointer = (OrdinaryPhase *) current;
	pointer->type = CPU;
	pointer->id = id;
	pointer->unit = unit;
	pointer->value = value;
	if (nextType != EMPTY)
		pointer->next = malloc(determineSize(nextType));
	else
		pointer->next = NULL;

	(*idLookupTabel)[*index].id = id;
	(*idLookupTabel)[*index].address = pointer;
	(*index)++;

	if (DEBUG_FLAG==1) {
		printf("New current: %x - Next: %x\n",pointer, pointer->next);
	}

	return pointer->next;

}



void * idLookup( int lastIndex, int id) {

	if (lastIndex > numberOfPhases) {
		printf("Error in function idLookup()! The index the search should start from is greater than the size of the lookup table!");
		exit(-1);
	}


	lastIndex--;
	do {
		if ((*idLookupTabel)[lastIndex].id == id)
			return (*idLookupTabel)[lastIndex].address;
		else
			lastIndex--;
	} while ((*idLookupTabel)[lastIndex+1].id != id && lastIndex >=0);


	printf("Error in function idLookup()! The address of the specified phase, with ID %d has not been found in memory! This should be impossible!\n", id);
	exit(-1);

}


void * setLOOPPhase(PointerToIDsLookupTabel tabel, int *index, void *current, int id, long int iterationsNumber, int idToLoopTo, PhaseType nextType) {

	if (DEBUG_FLAG==1) {
		printf("Old current %x ",current);
	}
	free(current);				
	current = malloc(sizeof(LoopPhase));

	LoopPhase *pointer = (LoopPhase *) current;
	pointer->type = LOOP;
	pointer->id = id;
	pointer->counter = iterationsNumber;
	pointer->iterationsNumber = iterationsNumber;
	pointer->loopTo = idLookup(*index, idToLoopTo);
	if (nextType != EMPTY)
		pointer->next = malloc(determineSize(nextType));
	else
		pointer->next = NULL;

	if (DEBUG_FLAG==1) {
		printf("New current: %x, loopTo: %x Next: %x\n", pointer, pointer->loopTo, pointer->next);
	}
	(*idLookupTabel)[*index].id = id;
	(*idLookupTabel)[*index].address = pointer;
	(*index)++;

	return pointer->next;

}

void * setFORKPhase(PointerToIDsLookupTabel tabel, int *index, void *current, int id, int numberOfNewThreads, int newThreadsInitialIDs[numberOfNewThreads], PhaseType nextType) {

	free(current);  
	current = malloc(sizeof(ForkPhase));

	ForkPhase *pointer = (ForkPhase *) current;
	pointer->type = FORK;
	pointer->id = id;

	PointerToArrayOfPointersToVoid newPhasesAddresses = malloc(sizeof(PointerToVoid) * numberOfNewThreads);
	int i;
	for (i = 0; i<numberOfNewThreads; i++)
		(*newPhasesAddresses)[i] = idLookup(*index, newThreadsInitialIDs[i]);

	pointer->newPhases = newPhasesAddresses;
	pointer->numberOfNewThreads = numberOfNewThreads;

	if (nextType != EMPTY)
		pointer->next = malloc(determineSize(nextType));
	else
		pointer->next = NULL;

	(*idLookupTabel)[*index].id = id;
	(*idLookupTabel)[*index].address = pointer;
	(*index)++;

	return pointer->next;

}

void * setJOINPhase(PointerToIDsLookupTabel tabel, int *index, void *current, int id, int numberOfThreadsToJoin, int initialPhasesOfThreadsToJoin[numberOfThreadsToJoin], PhaseType nextType) {

	free(current);
	current = malloc(sizeof(JoinPhase));

	JoinPhase *pointer = (JoinPhase *) current;
	pointer->type = JOIN;
	pointer->id = id;


	PointerToArrayOfPointersToVoid initialPhasesAddresses = malloc(sizeof(PointerToVoid) * numberOfThreadsToJoin);
	int i;
	for (i = 0; i<numberOfThreadsToJoin; i++)
		(*initialPhasesAddresses)[i] = idLookup(*index, initialPhasesOfThreadsToJoin[i]);

	pointer->initialPhases = initialPhasesAddresses;
	pointer->numberOfThreadsToJoin = numberOfThreadsToJoin;

	if (nextType != EMPTY)
		pointer->next = malloc(determineSize(nextType));
	else
		pointer->next = NULL;
	(*idLookupTabel)[*index].id = id;
	(*idLookupTabel)[*index].address = pointer;
	(*index)++;

	return pointer->next;

}

void initializeTabels() {
	pidLookup = malloc(sizeof(PIDsLookupTabelElement) * (numberOfThreads-1)); 

	idLookupTabel= malloc(sizeof(IDsLookupTabelElement)*numberOfPhases);
	argumentTabel = malloc(sizeof(ArgumentTabelElement)*numberOfThreads);

	int i;

	for (i = 0; i<numberOfThreads-1; i++) {
		(*pidLookup)[i].pid = 0;
		(*pidLookup)[i].initialPhase = NULL; 
	}

	for (i = 0; i<numberOfPhases; i++) {
		(*idLookupTabel)[i].id = 0;
		(*idLookupTabel)[i].address = NULL; 
	}

	for (i = 0; i<numberOfThreads; i++) {
		(*argumentTabel)[i].initialAddress = NULL;
		(*argumentTabel)[i].arg = NULL; 
	}

}	


#include "taskgraphs.model"


pid_t pidRetrieve(void *address) {

	int i=0;
	do {
		if (DEBUG_FLAG==1){
			printf("Searching for address: %x. In index i = %d there's PID: %d and Address: %x\n",address, i,(*pidLookup)[i].pid, (*pidLookup)[i].initialPhase);
		}
		if ((*pidLookup)[i].initialPhase == address) {
			if (DEBUG_FLAG==1){
				printf("Found: %d \n", (*pidLookup)[i].pid);
			}
			return (*pidLookup)[i].pid;
		}
		else {
			if (DEBUG_FLAG==1){
				printf("%x different to %x, continuing with next iteration.\n", address, (*pidLookup)[i].initialPhase);
			}
			i++;
		}
	} while ((*pidLookup)[i-1].initialPhase != address && i < numberOfThreads -1 );

	printf("Error in function pidRetrieve()! The address %x has not been found in memory! This should be impossible!\n", address);
	exit(-1);


}

void testPrint(void * root) {

	void *generic = root;
	OrdinaryPhase *pointer;
	PointerToVoid startingAddress[numberOfThreads-1];
	int indexStartingAddressArray=0, j=0;

	printf("Parsing MAIN thread\n");


	do {	

		do {

			pointer = generic;
			if (pointer->type == CPU || pointer->type == IO) {
				OrdinaryPhase * current = generic;
				printf("Address: %x - ID: %d - TYPE: %d - UNIT: %d - VALUE: %d - NEXT: %x \n", current, current->id, current->type, current->unit, current->value, current->next);
				generic = current->next;
			}
			else if (pointer->type == LOOP) {
				LoopPhase *current = generic;
				printf("Address: %x - ID: %d - TYPE: %d - COUNTER: %ld - ITERATIONS NUMBER: %ld - LOOP TO: %x - NEXT: %x\n", current, current->id, current->type, current->counter, current->iterationsNumber, current->loopTo, current->next);
				generic = current->next;	
			}
			else if (pointer->type == FORK) {
				ForkPhase *current = generic;
				printf("Address: %x - ID: %d - TYPE: %d - NEW PHASES: [", current, current->id, current->type);
				int i;
				for (i=0; i<current->numberOfNewThreads; i++) {
					printf("%x,",(*current->newPhases)[i]);
					startingAddress[indexStartingAddressArray]=(*current->newPhases)[i];
					indexStartingAddressArray++;
				}
				printf("] - NUMBER OF NEW THREADS: %d - NEXT: %x \n", current->numberOfNewThreads, current->next);
				generic = current->next;
			}
			else if (pointer->type == JOIN) {
				JoinPhase *current = generic;
				printf("Address: %x - ID: %d - TYPE: %d - FIRST PHASES: [", current, current->id, current->type);
				int i;
				for (i=0; i<current->numberOfThreadsToJoin; i++)
					printf("%x,",(*current->initialPhases)[i]);
				printf("] - NUMBER OF THREADS TO JOIN: %d - NEXT: %x \n", current->numberOfThreadsToJoin, current->next);
				generic = current->next;
			}

		} while (generic != NULL);

		generic = startingAddress[j];
		j++;
		if (j!=numberOfThreads)
			printf("Parsing thread number %d\n", j);


	} while (j!=numberOfThreads);



}

Boolean isEven(unsigned long long number) {

	if (number & 0x01 == 1)
		return false;
	else return true;

}

void executeCPUPhase(OrdinaryPhase *pointer, ThreadUtilities *tu) {

	if (pointer->unit == CYCLE) {
		int i,j, row, column;
		for (i = 0; i < pointer->value; i++) {

			row = floor((tu->m*genrand64_real2()) + 1);
			column = floor((tu->n*genrand64_real2()) + 1);

			Element * op1 = (*tu->rootA)[row-1];
			Element * op2 = (*tu->rootB)[column-1];
			Element * product = (*tu->rootC)[row-1];
			while (product->position != column-1 )
				product = product->next;

			product->value = 0;

			for (j = 0; j < tu->p; j++) {
				product->value += op1->value * op2->value;
				op1 = op1->next;
				op2 = op2->next;

			}

			//Anckwoledge the user about the successful execution
			printf("CPU OPERATION EXECUTED - Process ID: %d - Phase ID: %d (operation n. %d out of %d)\n", getpid(), pointer->id, i+1, pointer->value);

			if (DEBUG_FLAG==1){
				printf("Result: (%d,%d): %lf\n", row, column, product->value);
				printf("For this thread ThreadUtilities is: %x, fileA: %d, fileB: %d, fileC: %d, m: %d n:%d p: %d rootA %d, rootB %d, rootC %d\n", tu, tu->fileA, tu->fileB, tu->fileC, tu->m, tu->n, tu->p, tu->rootA, tu->rootB, tu->rootC);   }
		}
	}



}

double readMatrixFile(int fileDescriptor, int rows, int columns, int * selectedRow, int * selectedColumn) {
if (DEBUG_FLAG==1){
	printf("fileDescriptor: %d, rows: %d, columns:  %d, selectedRow: %x,selectedColumn : %x\n",fileDescriptor, rows, columns, selectedRow, selectedColumn);
}
	double *value = malloc(sizeof(double)); 
	*selectedRow = floor((rows*genrand64_real2()) + 1);
	*selectedColumn = floor((columns*genrand64_real2()) + 1);
	long int offset = ((*selectedRow-1) * columns + (*selectedColumn) )* sizeof(double); 
	int result = pread(fileDescriptor,(double *)value,sizeof(double),offset);
	if (result != sizeof(double)) {
		//For no reason the pread() shall not read the entire double. It's not possible by construction.
		printf("Error while reading from disk - IO phase.\n");
		exit(-1);
	}

	if (DEBUG_FLAG==1){
		printf("Value read: %lf from matrix %d - row: %d column: %d offset: %ld \n", *value, fileDescriptor, *selectedRow, *selectedColumn, offset);
	}

	double val = *value;
	free(value);
	return val;
}

void memorizeElement(pointerToElements root, double value, int var1, int var2) {
	Element * current = (*root)[var1-1]; 
	while (current->position != var2-1 )
		current = current->next;
	current->value = value;
	current->valid = true;

	if (DEBUG_FLAG==1){
		printf("Position: %d\n", current->position);
	}

}

double retrieveElement(pointerToElements root, int rows, int columns, int *selectedRow, int *selectedColumn) {
	*selectedRow = floor((rows*genrand64_real2()) + 1);
	*selectedColumn = floor((columns*genrand64_real2()) + 1);
	Element * current = (*root)[*selectedRow-1]; 
	while (current->position != *selectedColumn-1 )
		current = current->next;
	return current->value;


}

void writeMatrixFile(int fileDescriptor, double val, int columns, int row, int column) {

	double *value = malloc(sizeof(double));
	*value = val;

	long int offset = ((row-1) * columns + column )* sizeof(double); 

	int result = pwrite(fileDescriptor,(double *)value,sizeof(double),offset);
	//For no reason the pread() shall not read the entire double. It's not possible by construction.
	if (result != sizeof(double)) {
		printf("Error while writing to disk - IO phase. - Write size differs from double size \n");
		exit(-1);
	}		

	if (DEBUG_FLAG==1){
		printf("Value written: %lf from matrix %d - row: %d column: %d offset: %ld \n", *value, fileDescriptor, row, column, offset);
	}
	free(value);	


}

void executeIOPhase(OrdinaryPhase *pointer, ThreadUtilities *tu) {

	if (pointer->unit == CYCLE) {
		int i ;
		unsigned long long rand1, rand2;
		int result, r, c;
		double value;
		Element * current;


		for (i = 0; i < pointer->value; i++) {

			rand1 =	genrand64_int64();
			if (isEven(rand1)) {
				//Read
				rand2 = genrand64_int64();
				if (isEven(rand2)) { //Read A
					value = readMatrixFile (tu->fileA, tu->m, tu->p, &r, &c);
					memorizeElement(tu->rootA,value,r,c); 
				}
				else {
					//Read B
					value = readMatrixFile (tu->fileB, tu->p, tu->n, &r, &c);
					memorizeElement(tu->rootB,value,c,r); 
				}

			}
			else {
				//Write on C
				value = retrieveElement(tu->rootC, tu->m, tu->n, &r, &c);
				writeMatrixFile(tu->fileC, value, tu->n, r, c);


			}
			//Anckwoledge the user about the successful execution
			printf("I/O OPERATION EXECUTED - Process ID: %d - Phase ID: %d (operation n. %d out of %d)\n", getpid(), pointer->id, i+1, pointer->value);
			if (DEBUG_FLAG==1){
				printf("For this thread ThreadUtilities is: %x, fileA: %d, fileB: %d, fileC: %d, m: %d n:%d p: %d rootA %d, rootB %d, rootC %d\n", tu, tu->fileA, tu->fileB, tu->fileC, tu->m, tu->n, tu->p, tu->rootA, tu->rootB, tu->rootC); 
			}

		}

	}

}

void * executeLOOPPhase(LoopPhase *pointer) {

	if (pointer->iterationsNumber >0) {
		if (pointer->counter > 0) {
			//Anckwoledge the user about the successful execution
			if (DEBUG_FLAG==1){
				printf("LOOP PHASE - Process ID: %d - Phase ID: %d (still %d repetition(s) left out of %d). Going back to %x (next would be %x)\n", getpid(), pointer->id, pointer->counter, pointer->iterationsNumber, pointer->loopTo, pointer->next);
			}
			else{
				printf("LOOP PHASE - Process ID: %d - Phase ID: %d (still %d repetition(s) left  out of %d). Going back to previous phase.)\n", getpid(), pointer->id, pointer->counter, pointer->iterationsNumber);
			}

			pointer->counter--;
			return pointer->loopTo;
		}
		else if (pointer->counter ==0) {
			//Anckwoledge the user about the successful execution
			if (DEBUG_FLAG==1){	
				printf("LOOP PHASE - Process ID: %d - Phase ID: %d (still %d repetition(s) left out of %d). Going on to %x \n", getpid(), pointer->id, pointer->counter, pointer->iterationsNumber, pointer->next);
			}
			else{
				printf("LOOP PHASE - Process ID: %d - Phase ID: %d (still %d repetition(s) left out of %d). Going on with next phase.)\n", getpid(), pointer->id, pointer->counter, pointer->iterationsNumber);

			}

			pointer->counter = pointer->iterationsNumber;
			return pointer->next;
		}
		else {
			printf("Error in EXECUTELOOPPHASE! Counter < 0, this point should be impossible to reach!\n");
			exit(-1);
		}
	}
	else if (pointer -> iterationsNumber ==0) {
		//Anckwoledge the user about the successful execution
		if (DEBUG_FLAG==1){	
			printf("LOOP PHASE - Process ID: %d - Phase ID: %d (infinite loop). Going back to %x \n", getpid(), pointer->id, pointer->loopTo);
		}
		else{
			printf("LOOP PHASE - Process ID: %d - Phase ID: %d (infinite loop). Going back to previous phase.)\n", getpid(), pointer->id);		
		}
		return pointer->loopTo;
	}
	else 
	{ 
		printf("Error in EXECUTELOOPPHASE! iterationsNumber < 0, this point should be impossible to reach!\n");

		exit(-1);
	}
}

PointerToArrayOfPIDs executeJOINPhase(JoinPhase *pointer, int * numberOfPids) {

	int i;
	PointerToArrayOfPIDs pidArray = malloc(sizeof(pid_t)*pointer->numberOfThreadsToJoin);

	for (i=0;i<pointer->numberOfThreadsToJoin; i++) {
		pid_t pidToWait = pidRetrieve((*(pointer->initialPhases))[i]);
		//Anckwoledge the user about the successful execution

		printf("JOIN PHASE - Process ID: %d - Phase ID: %d. Waiting Process ID: %d \n", getpid(), pointer->id, pidToWait);

		int result = waitpid(pidToWait,NULL,0);
		if (result == -1) {
			printf("Error while waiting process - Join Phase - Errno: %d \n", errno);
			exit(-1);
		}
		(*pidArray)[i] = pidToWait;

	}

	*numberOfPids = pointer->numberOfThreadsToJoin;
	//Anckwoledge the user about the successful execution	
	if (DEBUG_FLAG==1){	

		printf("Process ID %d has waited for all the processes specified in Phase ID: %d. Going on to: %x \n", getpid(), pointer->id, pointer->next);
	}
	else {
		printf("Process ID %d has waited for all the processes specified in Phase ID: %d. Going on with next phase. \n", getpid());

	}

	return pidArray;
}


int positionLookupAndSet(void * address) {
	int i;
	for (i=0; i<numberOfThreads; i++) {
		if ((*pidLookup)[i].initialPhase == address) {
			return i;
		}
		else if ( (*pidLookup)[i].initialPhase == NULL) {
			(*pidLookup)[i].initialPhase = address;
			return i;
		}
	}

	printf("Error in function positionLookupAndSet()! The address %x has not been found in memory and the pidLookup tabel is full! This should be impossible!\n", address);
	exit(-1);


}

ThreadUtilities * argumentRetrieve (void * address){
	int i=0;
	do {
		if ((*argumentTabel)[i].initialAddress == address) {
			return (*argumentTabel)[i].arg;
		}
		else {
			i++;
		}
	} while ((*argumentTabel)[i-1].initialAddress != address && i < numberOfThreads);

	printf("Error in function argumentRetrieve()! The address %x has not been found in memory! This should be impossible!\n", address);
	exit(-1);


}

void setOrdinaryStartTimestamp(Statistics *stat, int id, PhaseType type, long int iterations) {

	stat->pid = getpid();
	stat->id = id;
	stat->type = type;
	stat->iterations = iterations;
	stat->numberOfPids = 0;
	stat->initialCPU = sched_getcpu(); 
	clock_gettime(CLOCK_TYPE,&(stat->start));

}


void setForkJoinStartTimestamp(Statistics *stat, int id, PhaseType type) {

	stat->pid = getpid();
	stat->id = id;
	stat->type = type;
	stat->initialCPU = sched_getcpu();
	clock_gettime(CLOCK_TYPE,&(stat->start));

}

Statistics* setForkJoinEndTimestamp(Statistics *stat, PointerToArrayOfPIDs pids) {
	clock_gettime(CLOCK_TYPE,&(stat->end));
	stat->finalCPU = sched_getcpu();
	stat->pids = pids;
	stat->next = malloc(sizeof(Statistics));
	return stat->next;
}


Statistics* setOrdinaryEndTimestamp(Statistics *stat) {
	clock_gettime(CLOCK_TYPE,&(stat->end));
	stat->finalCPU = sched_getcpu(); 
	stat->next = malloc(sizeof(Statistics));
	return stat->next;
}

void writeExactly(int file, char *toWrite) {
	char * current = toWrite;
	int i=0;
	while(*current != '\0') { 
		current +=sizeof(char);
		i++; }

	int result = write(file,toWrite,sizeof(char)*i);
	if (result != sizeof(char)*i) {
		printf("Error in writing statistics!\n");
		exit(-1);
	}


}

char * typeToString(PhaseType type) {

	char * string = malloc(sizeof(char)*6); 


	if (type == CPU) 
		sprintf(string,"CPU");
	else if (type == IO) 
		sprintf(string,"IO");
	else if (type == LOOP) 
		sprintf(string,"LOOP");
	else if (type == FORK) 
		sprintf(string,"FORK");
	else if (type == JOIN) 
		sprintf(string,"JOIN");

	return string;


}


void writeAndCheckError(int file, void * buffer, size_t size) {

	int result = write(file,buffer,size);
	if (result != size) {
		printf("Error in writing log files!\n");
		exit(-1);
	}

}

void builtLogFile(Statistics * pointer, int file) {

	Statistics * current = pointer;
	int i;
	while(current->next!=NULL) {

		writeAndCheckError(file,&(current->pid),sizeof(pid_t));
		writeAndCheckError(file,&(current->id),sizeof(int));
		writeAndCheckError(file,&(current->initialCPU),sizeof(int));
		writeAndCheckError(file,&(current->finalCPU),sizeof(int));
		writeAndCheckError(file,&(current->type),sizeof(PhaseType));
		writeAndCheckError(file,&(current->iterations),sizeof(long int));
		writeAndCheckError(file,&((current->start).tv_sec),sizeof(time_t));
		writeAndCheckError(file,&((current->start).tv_nsec),sizeof(long));
		writeAndCheckError(file,&((current->end).tv_sec),sizeof(time_t));
		writeAndCheckError(file,&((current->end).tv_nsec),sizeof(long));
		writeAndCheckError(file,&(current->numberOfPids),sizeof(int));
		for (i=0; i<current->numberOfPids;i++) 
			writeAndCheckError(file,&((*current->pids)[i]),sizeof(pid_t));

		current = current->next;

	}


}

// Test function
void readLogFile(int file){

	void readAndCheckError(int file, void * buffer, size_t size, Boolean * sentinel) {

		if (*sentinel == true) {
			int result = read(file,buffer,size);
			if (result != size) 
				*sentinel = false;
		}


	}

	lseek(file,0L, SEEK_SET);

	Statistics * buffer = malloc(sizeof(Statistics));
	int i;
	Boolean sentinel = true;
	printf("------------------------------ PARSING LOG FILE ---------------------------------- \n");

	while(sentinel == true) {

		readAndCheckError(file,&(buffer->pid),sizeof(pid_t), &sentinel);
		readAndCheckError(file,&(buffer->id),sizeof(int), &sentinel);
		readAndCheckError(file,&(buffer->initialCPU),sizeof(int),&sentinel);
		readAndCheckError(file,&(buffer->finalCPU),sizeof(int),&sentinel);
		readAndCheckError(file,&(buffer->type),sizeof(PhaseType),&sentinel);
		readAndCheckError(file,&(buffer->iterations),sizeof(long int),&sentinel);
		readAndCheckError(file,&((buffer->start).tv_sec),sizeof(time_t),&sentinel);
		readAndCheckError(file,&((buffer->start).tv_nsec),sizeof(long),&sentinel);
		readAndCheckError(file,&((buffer->end).tv_sec),sizeof(time_t),&sentinel);
		readAndCheckError(file,&((buffer->end).tv_nsec),sizeof(long),&sentinel);
		readAndCheckError(file,&(buffer->numberOfPids),sizeof(int),&sentinel);
		printf("Entry: %d %d %d %d %d %ld %ld %ld %ld %ld %d ",buffer->pid, buffer->id, buffer->initialCPU, buffer->finalCPU, buffer->type, buffer->iterations, (buffer->start).tv_sec, (buffer->start).tv_nsec, (buffer->end).tv_sec, (buffer->end).tv_nsec, buffer->numberOfPids);

		if(buffer->numberOfPids > 0)
			buffer->pids = malloc(sizeof(pid_t)* buffer->numberOfPids);

		for (i=0; i<buffer->numberOfPids;i++) {
			readAndCheckError(file,&((*(buffer->pids))[i]),sizeof(pid_t),&sentinel);
			printf("%d ",(*(buffer->pids))[i]);
		}

		printf("\n");


	}


}


void writeStatisticsOnFile(Statistics * pointer, int file) {

	char string[STRING_LENGTH];
	char tempString[STRING_LENGTH];
	int i;
	Statistics * current = pointer;


	sprintf(string,"STATISTICS FOR PROCESS %d \n\n PHASE ID\tTYPE\tINITIAL CPU\tFINAL CPU\tN. OPERATIONS\tSTART TIME\t\tEND TIME\t\t\tDURATION\t\t\tNOTE  \n",getpid());
	writeExactly(file,string);

	while(current->next!=NULL) {
		if (current->type == IO || current->type== CPU)
			sprintf(string,"%d\t%s\t%d\t\t%d\t\t%ld\t\t%lf\t%lf\t\t%lf\t\t\t\t-\n",current->id, typeToString(current->type), current->initialCPU, current->finalCPU, current->iterations, computeExtendedTime(current->start), computeExtendedTime(current->end), computeExtendedTime(current->end) - computeExtendedTime(current->start) );
		else {
			if (current->type == FORK) 
				sprintf(string,"%d\t%s\t%d\t\t%d\t\t-\t\t%lf\t%lf\t\t%lf\t\t\t\tProcesses created: ",current->id, typeToString(current->type), current->initialCPU, current->finalCPU, computeExtendedTime(current->start), computeExtendedTime(current->end), computeExtendedTime(current->end) - computeExtendedTime(current->start) );
			else if (current->type == JOIN)
				sprintf(string,"%d\t%s\t%d\t\t%d\t\t-\t\t%lf\t%lf\t\t%lf\t\t\t\tProcesses waited: ",current->id, typeToString(current->type),current->initialCPU, current->finalCPU, computeExtendedTime(current->start), computeExtendedTime(current->end), computeExtendedTime(current->end) - computeExtendedTime(current->start) );

			for (i=0; i < current->numberOfPids; i++)	{
				sprintf(tempString,"%d ",(*current->pids)[i]);
				strcat(string,tempString);
			} 

			strcat(string,"\n");
		}

		writeExactly(file,string);
		current = current->next;
	}


}

PointerToArrayOfPIDs executeFORKPhase(ForkPhase *pointer, int * numberOfPids) ; // Will be implemented later in this file.



void simulate(void *root) {


	ThreadUtilities *tu = argumentRetrieve (root);


	void *generic = root;
	OrdinaryPhase *pointer;
	do {

		pointer = generic;
		if (pointer->type == CPU) {
			OrdinaryPhase * current = generic;
			setOrdinaryStartTimestamp(tu->currentStat, current->id, CPU, current->value);
			executeCPUPhase(current, tu);
			tu->currentStat = setOrdinaryEndTimestamp(tu->currentStat);
			generic = current->next;
		}
		else if (pointer->type == IO) {
			OrdinaryPhase * current = generic;
			setOrdinaryStartTimestamp(tu->currentStat, current->id, IO, current->value);
			executeIOPhase(current, tu);
			tu->currentStat = setOrdinaryEndTimestamp(tu->currentStat);
			generic = current->next;
		}	
		else if (pointer->type == LOOP) {
			LoopPhase *current = generic;
			generic = executeLOOPPhase(current);

		}
		else if (pointer->type == FORK) {
			ForkPhase *current = generic;
			setForkJoinStartTimestamp (tu->currentStat, current->id, FORK);
			PointerToArrayOfPIDs result = executeFORKPhase(current,&(tu->currentStat->numberOfPids));
			tu->currentStat = setForkJoinEndTimestamp(tu->currentStat, result);
			generic = current->next;
		}
		else if (pointer->type == JOIN) {
			JoinPhase *current = generic;
			setForkJoinStartTimestamp (tu->currentStat, current->id, JOIN);
			PointerToArrayOfPIDs result = executeJOINPhase(current, &(tu->currentStat->numberOfPids));
			tu->currentStat = setForkJoinEndTimestamp(tu->currentStat, result);
			generic = current->next;
		}
		else {
			printf("Error in SIMULATE procedure! This point should be impossible to reach! \n");
			exit(-1);
		}
	} while (generic != NULL);

	//Here the process has finished.

	if(DEBUG_FLAG==1) {
		writeStatisticsOnFile(tu->initialStat, tu->statFile); //Test function
	}
	else{

		int i;
for(i=0;i<numberOfThreads;i++){
	
		char iString[INDEX_LENGTH]; 
		sprintf(iString,"%d",i);

		char pathnameStat[PATHNAME_LENGTH] = STAT_PATHNAME;
		strcat(pathnameStat, iString);

	unlink(pathnameStat);
}


	}

	builtLogFile(tu->initialStat,tu->logFile);

	if(DEBUG_FLAG==1) {		
		readLogFile(tu->logFile);
	}


	printf("Thread %d has finished succesfully! \n", getpid());

}

PointerToArrayOfPIDs executeFORKPhase(ForkPhase *pointer, int *numberOfPids) {

	int i;

	PointerToArrayOfPIDs pidArray = malloc(sizeof(pid_t)*pointer->numberOfNewThreads);

	for (i=0; i<pointer->numberOfNewThreads; i++) {
		void (*pf) (void *); //Pointer to a function, needed for clone().
		pf = &simulate;
		void * stack = malloc(STACK_SIZE);

		void *arg = (*pointer->newPhases)[i];

		pid_t result = clone(pf,stack + STACK_SIZE, SIGCHLD|CLONE_FS|CLONE_VM|CLONE_FILES,arg);

		if (result == -1) {
			printf("Error in creating processes - FORK phase. - Errno: %d \n", errno);
			exit(-1);
		}


		(*pidArray)[i] = result;
		int index = positionLookupAndSet((*pointer->newPhases)[i]);
		(*pidLookup)[index].pid = result;

		if(DEBUG_FLAG==1) {	
			printf("Memory status: in index %d there's pid %d and address %x \n", index, (*pidLookup)[index].pid, (*pidLookup)[index].initialPhase);
		}
		else{
			printf("FORK PHASE - Process ID: %d - Phase ID: %d - Process ID %d has been created. \n", getpid(), pointer->id, result);
		}

	}

	*numberOfPids = pointer->numberOfNewThreads;

	//Test print
	if(DEBUG_FLAG==1) {
		printf("Process ID %d has created all the processes specified in Phase ID: %d. Going on to %d \n", getpid(), pointer->id, pointer->next);
	}
	else {
		printf("Process ID %d has created all the processes specified in Phase ID: %d. Going on with next phase. \n", getpid());
	}

	return pidArray;

}






int main(int argc, char ** argv)
{
	struct timespec st;
	clock_gettime(CLOCK_TYPE,&st);

	errno = 0;  //Because strtoll can return negative value

	if (argc != 2) {
		printf("Error! You shold specify a single parameter");
		return(-1);
	}

	int genMatrix = strtoll(argv[1],NULL,10);
	if (errno != 0 || !(genMatrix==0 || genMatrix==1)) {
		printf("The parameter must be 0 or 1!\n");
		return(-1);
	}



	//MASCOTS' 14 demonstration taskgraph 1. 
	void * firstPhase = buildDemoTaskGraph(argv[1]);

	//MASCOTS' 14 demonstration taskgraph 2. 
	//void * firstPhase = buildValidationTaskGraph(argv[1]);


	createMatricesAndElementsStructures(genMatrix);
	if(DEBUG_FLAG==1) {
		testPrint (firstPhase);
	}
	simulate (firstPhase);


	printf("Finish~!\n");


	return (0); 
}
