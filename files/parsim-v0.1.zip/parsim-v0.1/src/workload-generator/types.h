/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * types.h
 * Copyright (C) 2013-2014 Andrea Rosà <andrea.rosa@usi.ch>
	 * 
 * workload-simulator is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
	 * 
 * workload-simulator is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib.h>
#include <time.h>
#define STACK_SIZE 65536 
#define DEBUG_FLAG 0

#define PATHNAME_LENGTH 100
#define DIMENSIONS_LENGTH 10
#define STRING_LENGTH 255
#define INDEX_LENGTH 5
#define NUMBER_LENGTH 250
#define MIN_M 20
#define MAX_M 40
#define MIN_N 20
#define MAX_N 30
#define MIN_P 30
#define MAX_P 40
#define MIN_MINRANDOM -1000000000000
#define MAX_MINRANDOM -10000000000
#define MIN_MAXRANDOM +10000000000
#define MAX_MAXRANDOM +1000000000000

#define A_PATHNAME "matrices/A."
#define B_PATHNAME "matrices/B."
#define C_PATHNAME "matrices/C."
#define STAT_PATHNAME "stats/STAT."
#define LOG_PATHNAME "logs/LOG."
#define GLOBAL_LOG_SUFFIX "GLOBAL"


#define CLOCK_TYPE CLOCK_BOOTTIME

//LaTeX
#define LINE_STYLE "very thick"
#define LINE_STYLE_FORK_JOIN "densely dotted"
#define FIRST_Y 0.1
#define OFFSET_Y 0.1

typedef enum
{
	false,
	true
} Boolean;


typedef enum PhaseType
{ CPU,
	IO,
	LOOP,
	FORK,
	JOIN,
	EMPTY
} PhaseType;

typedef enum ValueType
{	CYCLE,
	MS
} ValueType;

typedef struct PIDsLookupTabelElement {
	pid_t pid;
	void * initialPhase; //Pointer to OrdinaryPhase, LoopPhase, ForkPhase or JoinPhase
} PIDsLookupTabelElement;

typedef PIDsLookupTabelElement PIDsLookupTabel[];

typedef PIDsLookupTabel *PointerToPIDsLookupTabel;

typedef struct IDsLookupTabelElement {
	int id;
	void * address;
} IDsLookupTabelElement;

typedef IDsLookupTabelElement IDsLookupTabel[];

typedef IDsLookupTabel *PointerToIDsLookupTabel;

typedef struct Element {
	double value;
	Boolean valid;
	long int position;
	struct Element * next;
} Element;	


typedef Element * pointerToElement;

typedef pointerToElement pointersArray[];

typedef pointersArray *pointerToElements;

typedef struct OrdinaryPhase {
	PhaseType type; //For this structure, type must be "CPU" or "IO"
	int id;
	ValueType unit;
	long int value;
	void *next; //Pointer to OrdinaryPhase, LoopPhase, ForkPhase or JoinPhase
} OrdinaryPhase;

typedef struct LoopPhase {
	PhaseType type; //For this structure, type must be "LOOP"
	int id;
	long int counter;
	long int iterationsNumber;
	void *loopTo; //Pointer to OrdinaryPhase, LoopPhase, ForkPhase or JoinPhase 
	void *next; //Pointer to OrdinaryPhase, LoopPhase, ForkPhase or JoinPhase
} LoopPhase;

typedef void *PointerToVoid; 	//Pointer to OrdinaryPhase, LoopPhase, ForkPhase or JoinPhase

typedef PointerToVoid ArrayOfPointersToVoid[]; 

typedef ArrayOfPointersToVoid *PointerToArrayOfPointersToVoid;

typedef pid_t ArrayOfPIDs[];

typedef ArrayOfPIDs *PointerToArrayOfPIDs;


typedef struct ForkPhase {
	PhaseType type; //For this structure, type must be "FORK"
	int id;
	PointerToArrayOfPointersToVoid newPhases;
	int numberOfNewThreads;
	void *next; //Pointer to OrdinaryPhase, LoopPhase, ForkPhase or JoinPhase
} ForkPhase;


typedef struct JoinPhase {
	PhaseType type; //For this structure, type must be "JOIN"
	int id;
	PointerToArrayOfPointersToVoid initialPhases; //These are the initial phases of each thread to be joined
	int numberOfThreadsToJoin;
	void *next; //Pointer to OrdinaryPhase, LoopPhase, ForkPhase or JoinPhase
} JoinPhase;

typedef struct Statistics {
	pid_t pid;
	int id;
	int initialCPU;
	int finalCPU;
	PhaseType type;
	long int iterations;	
	struct timespec start;
	struct timespec end;
	PointerToArrayOfPIDs pids; //forked or joined
	int numberOfPids;
	struct Statistics *next;
} Statistics;

typedef struct ThreadUtilities {
	int fileA;
	int fileB;
	int fileC;
	int statFile;
	int logFile;
	int m;
	int n;
	int p;
	pointerToElements rootA;
	pointerToElements rootB;
	pointerToElements rootC;
	Statistics * initialStat;
	Statistics * currentStat;
	void * root;
} ThreadUtilities;

typedef struct ArgumentTabelElement {
	void * initialAddress;
	ThreadUtilities *arg;
} ArgumentTabelElement;

typedef ArgumentTabelElement ArgumentTabel[];

typedef ArgumentTabel * PointerToArgumentTabel;


typedef struct FileToPid {
	int index;
	pid_t pid;
	double start;
	double end;
	struct FileToPid *next;
}FileToPid;

typedef struct TimeQuanta {
	double start;
	double end;
	int nThread;
	struct TimeQuanta *next;
} TimeQuanta;


typedef struct PhaseQuanta {
	double start;
	double end;
	int nPhase;
	struct PhaseQuanta *next;
} PhaseQuanta;

typedef double DoubleArray[];
typedef DoubleArray * PointerToArrayOfDoubles;

typedef struct PhaseTimes {
	double * startIO;
	double * startCPU;
	double * startFORK;
	double * startJOIN;
	double * endIO;
	double * endCPU;
	double * endFORK;
	double * endJOIN;
} PhaseTimes; 




