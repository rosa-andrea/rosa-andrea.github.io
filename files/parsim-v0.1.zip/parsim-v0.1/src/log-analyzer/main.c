/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * main.c
 * Copyright (C) 2013-2014 Andrea Rosà <andrea.rosa@usi.ch>
 * 
 * log-analyzer is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
	 * 
 * log-analyzer is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


 /*  Parameters of main function:
 *	 argv[1]: input log files prefix (e.g., "LOG.")
 *	 argv[2]: output execution profile prefix (e.g., "TOPLOT.")
 *	 argv[3]: output parallelism profile filename (e.g., "ACTIVE.PLOT")
 *	 argv[4]: output phases profiles prefix (e.g., "PHASE.")			 
 */

#include <stdio.h>
#include "workload-generator/types.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h> 
#include <math.h>
#include <linux/sched.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>


double computeExtendedTime(struct timespec time) {

	return (double) time.tv_sec * (double) 1000 + (double) ( (double) time.tv_nsec / (double) 1000000 );

}


void sort (double *a, int n) //Quicksort. Adapted version from http://rosettacode.org/wiki/Sorting_algorithms/Quicksort#C 
{ 
	if (n < 2)
		return;
	double p = a[n / 2];
	double *l = a;
	double *r = a + n - 1;
	while (l <= r) {
		if (*l < p) {
			l++;
			continue;
		}
		if (*r > p) {
			r--;
			continue; // we need to check the condition (l <= r) every time we change the value of l or r
		}
		double t = *l;
		*l++ = *r;
		*r-- = t;
	}
	sort(a, r - a + 1);
	sort(l, a + n - l);
}


PhaseTimes computePhaseQuanta(Statistics *root, int nIO, int nCPU, int nFORK, int nJOIN, double minTime) {

	double * startIO = malloc(sizeof(double)* nIO);
	double * endIO = malloc(sizeof(double)* nIO);
	double * startCPU = malloc(sizeof(double)* nCPU);
	double * endCPU = malloc(sizeof(double)* nCPU);
	double * startFORK =  malloc(sizeof(double)* nFORK);
	double * endFORK = malloc(sizeof(double)* nFORK);
	double * startJOIN = malloc(sizeof(double)* nJOIN);
	double * endJOIN = malloc(sizeof(double)* nJOIN);

	int indexIO, indexCPU, indexFORK, indexJOIN;

	indexIO=indexCPU=indexFORK=indexJOIN=0;

	Statistics *current = root;

	while (current != NULL) {
		if (current->type == CPU) {
			startCPU[indexCPU] = computeExtendedTime(current->start) - minTime;
			endCPU[indexCPU] = computeExtendedTime(current->end) - minTime;
			indexCPU++;
		}
		else if (current->type == IO) {
			startIO[indexIO] = computeExtendedTime(current->start) - minTime;
			endIO[indexIO] = computeExtendedTime(current->end) - minTime;
			indexIO++;
		}
		else if (current->type == FORK) {
			startFORK[indexFORK] = computeExtendedTime(current->start) - minTime;
			endFORK[indexFORK] = computeExtendedTime(current->end) - minTime;
			indexFORK++;
		}
		else if (current->type == JOIN) {
			startJOIN[indexJOIN] = computeExtendedTime(current->start) - minTime;
			endJOIN[indexJOIN] = computeExtendedTime(current->end) - minTime;
			indexJOIN++;
		}

		current = current->next;
	}

	sort(startCPU, nCPU);
	sort(endCPU, nCPU);
	sort(startIO, nIO);
	sort(endIO, nIO);
	sort(startFORK, nFORK);
	sort(endFORK, nFORK);
	sort(startJOIN, nJOIN);
	sort(endJOIN, nJOIN);

	//Test print
	if (DEBUG_FLAG==1) {
	for (indexIO = 0; indexIO < nIO; indexIO++)
		printf("IO - index: %d, start: %lf end: %lf\n", indexIO, startIO[indexIO], endIO[indexIO]);
	for (indexCPU = 0; indexCPU < nCPU; indexCPU++)
		printf("CPU - index: %d, start: %lf end: %lf\n", indexCPU, startCPU[indexCPU], endCPU[indexCPU]);
	for (indexFORK = 0; indexFORK < nFORK; indexFORK++)
		printf("FORK - index: %d, start: %lf end: %lf\n", indexFORK, startFORK[indexFORK], endFORK[indexFORK]);
	for (indexJOIN = 0; indexJOIN < nJOIN; indexJOIN++)
		printf("JOIN - index: %d, start: %lf end: %lf\n", indexJOIN, startJOIN[indexJOIN], endJOIN[indexJOIN]);

	}

	PhaseTimes result;
	result.startCPU = startCPU;
	result.endCPU = endCPU;
	result.startIO = startIO;
	result.endIO = endIO;
	result.startFORK = startFORK;
	result.endFORK = endFORK;
	result.startJOIN = startJOIN;
	result.endJOIN = endJOIN;

	return result;


}


TimeQuanta * createTimeQuanta(FileToPid *root, int nThread, double minTime) {

	//Root contains time intervals for every process. Let's sort them in different arrays. 
	double startingTimes[nThread];
	double endingTimes[nThread];

	FileToPid *current = root;
	int i;
	for (i=0; i<nThread; i++) {
		startingTimes[i] = current->start - minTime;
		endingTimes[i] = current->end - minTime;
		current = current->next;
	}

	sort(&startingTimes, nThread);
	sort(&endingTimes, nThread);

	int startIndex=0, endIndex=0;

	TimeQuanta * timeQuanta = malloc(sizeof(TimeQuanta));
	timeQuanta->start = startingTimes[startIndex];
	timeQuanta->nThread = 1;
	startIndex++;

	TimeQuanta * timeQuantum = timeQuanta;

	int prevThread;

	while(startIndex < nThread || endIndex < nThread) {
		if ((startIndex < nThread && startingTimes[startIndex] < endingTimes[endIndex]) || endIndex >= nThread) {
			timeQuanta->end = startingTimes[startIndex];
			prevThread = timeQuanta->nThread;
			timeQuanta->next = malloc(sizeof(TimeQuanta));
			timeQuanta = timeQuanta->next;
			timeQuanta->nThread = prevThread +1;
			timeQuanta->start = startingTimes[startIndex];
			startIndex++; }
		else if ((endIndex < nThread && startingTimes[startIndex] > endingTimes[endIndex] )|| startIndex >= nThread) {
			timeQuanta->end = endingTimes[endIndex];
			prevThread = timeQuanta->nThread;
			timeQuanta->next = malloc(sizeof(TimeQuanta));
			timeQuanta = timeQuanta->next;
			timeQuanta->nThread = prevThread -1;
			timeQuanta->start = endingTimes[endIndex];
			endIndex++;

		} 
		else {
			startIndex++;
			endIndex++;

		}
	}

	//Test print
	if (DEBUG_FLAG==1) {
	timeQuanta = timeQuantum;
	while (timeQuanta -> next != NULL) {
		printf("Start: %lf End %lf nThread %d\n", timeQuanta->start, timeQuanta->end, timeQuanta->nThread);
		timeQuanta = timeQuanta->next;
	}
	}
	return timeQuantum;


}


PhaseQuanta * createPhaseQuanta(int length, double startTimes[length], double endTimes[length]) {
	//Recall: startTimes and endTimes are already sorted

	int startIndex=0, endIndex=0;

	if (DEBUG_FLAG==1) {
	int i;
	for (i = 0; i < length; i++)
		printf("Start: %lf, end: %lf, i: %d\n", startTimes[i], endTimes[i], i);
	}

	PhaseQuanta * phaseQuanta = malloc(sizeof(PhaseQuanta));
	phaseQuanta->start = startTimes[startIndex];
	phaseQuanta->nPhase = 1;
	startIndex++;

	PhaseQuanta * phaseQuantum = phaseQuanta;

	int prevPhase;

	while(startIndex < length || endIndex < length) {
		if ((startIndex < length && startTimes[startIndex] < endTimes[endIndex]) || endIndex >= length) {
			phaseQuanta->end = startTimes[startIndex];
			prevPhase = phaseQuanta->nPhase;
			phaseQuanta->next = malloc(sizeof(PhaseQuanta));
			phaseQuanta = phaseQuanta->next;
			phaseQuanta->nPhase = prevPhase +1;
			phaseQuanta->start = startTimes[startIndex];
			startIndex++; }
		else if ((endIndex < length && startTimes[startIndex] > endTimes[endIndex] )|| startIndex >= length) {
			phaseQuanta->end = endTimes[endIndex];
			prevPhase = phaseQuanta->nPhase;
			phaseQuanta->next = malloc(sizeof(PhaseQuanta));
			phaseQuanta = phaseQuanta->next;
			phaseQuanta->nPhase = prevPhase -1;
			phaseQuanta->start = endTimes[endIndex];
			endIndex++;

		} 
		else {
			startIndex++;
			endIndex++;

		}
	}

	if (DEBUG_FLAG==1) {
	phaseQuanta = phaseQuantum;
	while (phaseQuanta -> next != NULL) {
		printf("Start: %lf End %lf nPhase %d\n", phaseQuanta->start, phaseQuanta->end, phaseQuanta->nPhase);
		phaseQuanta = phaseQuanta->next;
	}
	}
	return phaseQuantum;



}



void readAndCheckError(int file, void * buffer, size_t size, Boolean * sentinel) {

	if (*sentinel == true) {
		int result = read(file,buffer,size);
		if (result != size) 
			*sentinel = false;
	}


}


void writeExactly(int file, char *toWrite) {
	char * current = toWrite;
	int i=0;
	while(*current != '\0') { 
		current +=sizeof(char);
		i++; }

	int result = write(file,toWrite,sizeof(char)*i);
	if (result != sizeof(char)*i) {
		printf("Error in writing statistics!\n");
		exit(-1);
	}


}

FileToPid * fileToPidByIndex(FileToPid *root, int index) {

	FileToPid *current = root;

	do {

		if (current->index == index) 
			return current;

		else current = current->next;
	} while (current->next != NULL);

	printf("Error in function fileToPidByIndex()! The index has not been found in memory! This should be impossible!\n");
	exit(-1);


}

FileToPid * fileToPidRetrieve(FileToPid *root, pid_t pid) {

	FileToPid *current = root;

	do {

		if (current->pid == pid) 
			return current;

		else current = current->next;
	} while (current->next != NULL);

	printf("Error in function fileToPidRetrieve()! The index has not been found in memory! This should be impossible!\n");
	exit(-1);


}

char * typeToString(PhaseType type) {

	char * string = malloc(sizeof(char)*20); 

	if (type == CPU) 
		sprintf(string,"CPU");
	else if (type == IO) 
		sprintf(string,"IO");
	else if (type == LOOP) 
		sprintf(string,"LOOP");
	else if (type == FORK) 
		sprintf(string,"FORK");
	else if (type == JOIN) 
		sprintf(string,"JOIN");

	return string;


}


void writeStatisticsOnFile(Statistics * pointer, int file, double minTime) {

	char string[STRING_LENGTH];
	char tempString[STRING_LENGTH];
	int i;
	Statistics * current = pointer;


	sprintf(string,"PID\tID\tTYPE\tI. CPU\tF. CPU\tITER\tSTART (ms)\tEND (ms)\tDUR.(ms)\tAVG DUR.(µs)\tNOTE  \n");
	writeExactly(file,string);

	while(current->next!=NULL) {
		if (current->type == IO || current->type== CPU)
			sprintf(string,"%d\t%d\t%s\t%d\t%d\t%ld\t%lf\t%lf\t%lf\t%lf\t-\n",current->pid, current->id, typeToString(current->type), current->initialCPU, current->finalCPU, current->iterations, computeExtendedTime(current->start) - minTime, computeExtendedTime(current->end) - minTime, computeExtendedTime(current->end) - computeExtendedTime(current->start), (double) ((computeExtendedTime(current->end) - computeExtendedTime(current->start)) * 1000 / current->iterations));
		else {
			if (current->type == FORK) 
				sprintf(string,"%d\t%d\t%s\t%d\t%d\t-\t%lf\t%lf\t%lf\t-\t\tProcesses created: ",current->pid, current->id, typeToString(current->type), current->initialCPU, current->finalCPU, computeExtendedTime(current->start) - minTime, computeExtendedTime(current->end) - minTime, computeExtendedTime(current->end) - computeExtendedTime(current->start) );
			else if (current->type == JOIN)
				sprintf(string,"%d\t%d\t%s\t%d\t%d\t-\t%lf\t%lf\t%lf\t-\t\tProcesses waited: ",current->pid, current->id, typeToString(current->type),current->initialCPU, current->finalCPU, computeExtendedTime(current->start) - minTime, computeExtendedTime(current->end) - minTime, computeExtendedTime(current->end) - computeExtendedTime(current->start) );

			for (i=0; i < current->numberOfPids; i++)	{
				sprintf(tempString,"%d ",(*current->pids)[i]);
				strcat(string,tempString);
			} 

			strcat(string,"\n");
		}

		writeExactly(file,string);
		current = current->next;
	}


}



void computeThreadTimes(Statistics * root, FileToPid * dest, int nThreads) {
	Statistics * currentStat = root;
	FileToPid * currentDest;

	//Note: Root is already ordered by starting time. 
	while(currentStat->next!=NULL) 
	{   
		currentDest = fileToPidRetrieve(dest,currentStat->pid);
		if (currentDest->start == -1 || computeExtendedTime (currentStat->start) < currentDest->start)
			currentDest-> start = computeExtendedTime(currentStat->start);
		if (computeExtendedTime (currentStat->end) > currentDest->end)
			currentDest-> end = computeExtendedTime(currentStat->end);
		currentStat = currentStat->next;
	}


}

void writePhaseTimes(PhaseQuanta * root, int file, double maxTime) {

	char string[STRING_LENGTH];
	PhaseQuanta * current = root;

	//For plotting reasons
	sprintf(string,"%lf %lf\n",(double) 0.0, (double) 0.0);
	writeExactly(file,string);

	sprintf(string,"%lf %lf\n",(double) current->start, (double) 0.0);
	writeExactly(file,string);


	while(current->next->next!=NULL) {
		sprintf(string,"%lf %lf\n",(double) current->start, (double) current->nPhase);
		writeExactly(file,string);
		current = current->next;
	}

	sprintf(string,"%lf %lf\n",(double) current->start, (double) current->nPhase);
	writeExactly(file,string);

	//For plotting reasons
	sprintf(string,"%lf %lf\n",(double) current->end, (double) 0.0);
	writeExactly(file,string);
	sprintf(string,"%lf %lf\n",maxTime, (double) 0.0);
	writeExactly(file,string);



}

void writeActiveThreadsOnFile(int file, TimeQuanta * root) {

	char string[STRING_LENGTH];
	TimeQuanta * current = root;


	//writeExactly(file,string);

	//For plotting reasons
	sprintf(string,"%lf %lf\n",(double) current->start, (double) 0.0);
	writeExactly(file,string);


	while(current->next->next!=NULL) { 

		sprintf(string,"%lf %lf\n",(double) current->start, (double) current->nThread);
		writeExactly(file,string);
		current = current->next;
	}

	sprintf(string,"%lf %lf\n",(double) current->start, (double) current->nThread);
	writeExactly(file,string);

	//For plotting reasons
	sprintf(string,"%lf %lf\n",(double) current->end, (double) 0.0);
	writeExactly(file,string);



}


void writeLaTeXPlot(Statistics * pointer, int file, pid_t pid, double minTime, int k) {

	char string[STRING_LENGTH];
	Statistics * current = pointer;

	while(current!=NULL) { 
		if (current->pid == pid)
			if (current->type == CPU || current->type == IO) {
				sprintf(string,"\\addplot [%s,%s] coordinates {(%lf,%lf)(%lf,%lf)};\n",LINE_STYLE, typeToString(current->type), (double) computeExtendedTime(current->start) - minTime, FIRST_Y + OFFSET_Y*k,  (double) computeExtendedTime(current->end) -minTime, FIRST_Y + OFFSET_Y*k);
				writeExactly(file,string); }
		else {
			sprintf(string,"\\addplot [%s, %s, %s] coordinates {(%lf,%lf)(%lf,%lf)};\n",LINE_STYLE, LINE_STYLE_FORK_JOIN, typeToString(current->type), (double) computeExtendedTime(current->start) - minTime, FIRST_Y + OFFSET_Y*k,  (double) computeExtendedTime(current->end) -minTime, FIRST_Y + OFFSET_Y*k);
			writeExactly(file,string); }


		current = current->next;
	}


}


pid_t pidRetrieve(FileToPid *root, int index) {

	FileToPid *current = root;

	do {
		if (current->index == index) 
			return current->pid;

		else current = current->next;
	} while (current ->next!= NULL);



	printf("Error in function pidRetrieve()! The pid has not been found in memory! This should be impossible!\n");
	exit(-1);


}


int main(int argc, char **argv)
{

	if (argc != 5) {
		printf("Error! You should pass 4 parameters as input!");
		return(-1);
	}

	char iString[INDEX_LENGTH];
	char pidString[5];
	int i = 0;
	int j;

	int nCPU = 0;
	int nIO = 0;
	int nFORK = 0;
	int nJOIN = 0;

	int file;

	double minTime = -1;
	double maxTime = -1;

	Statistics * buffer, *root, *temp;

	Boolean sentinel = true;
	Boolean firstTime = true;
	Boolean firstTimeOfFile = true;
	char pathname[PATHNAME_LENGTH];
	char pathname2[PATHNAME_LENGTH];
	char pathname3[PATHNAME_LENGTH];
	char pathname4[PATHNAME_LENGTH];

	FileToPid * fileToPid = malloc(sizeof(FileToPid));
	FileToPid * currentFileToPid = fileToPid;


	//Read the log files

	while(1) {

		sprintf(iString,"%d",i);
		sprintf(pathname, "%s", argv[1]);
		strcat(pathname, iString);
		file = open(pathname,O_RDONLY);

		printf("Parsing file %s\n", pathname);

		if (file == -1 && errno == ENOENT) {//Il file non esiste. 
			errno = 0;
			break;
		}


		while(sentinel == true) {

			buffer = malloc(sizeof(Statistics));
			if (firstTime) {
				root = buffer;
			}

			readAndCheckError(file,&(buffer->pid),sizeof(pid_t), &sentinel);
			if (firstTimeOfFile && sentinel == true)
			{   firstTimeOfFile = false;
				currentFileToPid->index = i;
				currentFileToPid->pid = buffer->pid;
				currentFileToPid->start = -1;
				currentFileToPid->end = -1; //Initialization
				currentFileToPid->next = malloc(sizeof(FileToPid));
				currentFileToPid = currentFileToPid->next;
			}
			readAndCheckError(file,&(buffer->id),sizeof(int), &sentinel);
			readAndCheckError(file,&(buffer->initialCPU),sizeof(int),&sentinel);
			readAndCheckError(file,&(buffer->finalCPU),sizeof(int),&sentinel);
			readAndCheckError(file,&(buffer->type),sizeof(PhaseType),&sentinel);
			if (sentinel) {
				if (buffer->type == CPU )
					nCPU++;
				else if (buffer->type == IO)
					nIO++;
				else if(buffer->type == FORK)
					nFORK++;
				else if (buffer->type == JOIN)
					nJOIN++;
			}
			readAndCheckError(file,&(buffer->iterations),sizeof(long int),&sentinel);
			readAndCheckError(file,&((buffer->start).tv_sec),sizeof(time_t),&sentinel);
			readAndCheckError(file,&((buffer->start).tv_nsec),sizeof(long),&sentinel);

			if (firstTime) {
				minTime = computeExtendedTime(buffer->start);
			}

			readAndCheckError(file,&((buffer->end).tv_sec),sizeof(time_t),&sentinel);
			readAndCheckError(file,&((buffer->end).tv_nsec),sizeof(long),&sentinel);

			if (sentinel)
				if (computeExtendedTime(buffer->end) - minTime > maxTime)
				maxTime = computeExtendedTime(buffer->end) - minTime;

			readAndCheckError(file,&(buffer->numberOfPids),sizeof(int),&sentinel);

			if(buffer->numberOfPids > 0)
				buffer->pids = malloc(sizeof(pid_t)* buffer->numberOfPids);

			for (j=0; j<buffer->numberOfPids;j++) {
				readAndCheckError(file,&((*(buffer->pids))[j]),sizeof(pid_t),&sentinel);

			}

			//Find correct position
			if (!firstTime && sentinel) {
				temp = root;

				while (temp -> next != NULL && computeExtendedTime(temp->next->start) < computeExtendedTime (buffer->start)) 	
					temp = temp->next;


				buffer->next = temp->next;
				temp -> next = buffer; 

			}

			firstTime = false;

		}

		//After having read a single file, switch to other ones.

		i++;
		sentinel = true;
		firstTimeOfFile = true;
	}

	int nThread = i;

	close(file);

	printf("Building textual statistics...\n");
	
	sprintf(pathname, "%s", argv[1]);
	strcat(pathname,GLOBAL_LOG_SUFFIX);
	file = open(pathname,O_RDWR|O_TRUNC|O_CREAT,0666);
	writeStatisticsOnFile (root, file, minTime);

	close(file);

	printf("Building execution profile...\n");
	
	int k;
	int file2, file3;

	for (k = 0; k < i; k++) {
		sprintf(iString,"%d",k);
		sprintf(pathname2, "%s", argv[2]);
		strcat(pathname2, iString);

		file2 = open(pathname2,O_RDWR|O_TRUNC|O_CREAT,0666); 

		writeLaTeXPlot(root, file2, pidRetrieve(fileToPid,k),minTime, k);

		close(file2);
	}



	printf("Building parallelism profile...\n");
	
	sprintf(pathname3, "%s", argv[3]);
	file3 = open(pathname3,O_RDWR|O_TRUNC|O_CREAT,0666);
	computeThreadTimes (root,fileToPid, nThread);
	TimeQuanta * firstTimeQuantum = createTimeQuanta(fileToPid,nThread,minTime);
	writeActiveThreadsOnFile(file3, firstTimeQuantum); 
	close(file3);

		printf("Building phases profile...\n");


	int file4;

	PhaseTimes phaseTimes = computePhaseQuanta(root, nIO, nCPU, nFORK, nJOIN, minTime);

	PhaseQuanta *quantaIO = createPhaseQuanta (nIO, phaseTimes.startIO, phaseTimes.endIO);
	PhaseQuanta *quantaCPU = createPhaseQuanta (nCPU, phaseTimes.startCPU, phaseTimes.endCPU);
	PhaseQuanta *quantaFORK = createPhaseQuanta (nFORK, phaseTimes.startFORK, phaseTimes.endFORK);
	PhaseQuanta *quantaJOIN = createPhaseQuanta (nJOIN, phaseTimes.startJOIN, phaseTimes.endJOIN);

	sprintf(pathname4, "%s", argv[4]);
	strcat(pathname4, "IO");
	file4 = open(pathname4,O_RDWR|O_TRUNC|O_CREAT,0666);
	writePhaseTimes(quantaIO, file4,maxTime);
	close(file4);

	
	sprintf(pathname4, "%s", argv[4]);
	strcat(pathname4, "CPU");
	file4 = open(pathname4,O_RDWR|O_TRUNC|O_CREAT,0666);
	writePhaseTimes(quantaCPU, file4,maxTime);
	close(file4);

	sprintf(pathname4, "%s", argv[4]);
	strcat(pathname4, "FORK");
	file4 = open(pathname4,O_RDWR|O_TRUNC|O_CREAT,0666);
	writePhaseTimes(quantaFORK, file4,maxTime);
	close(file4);

	sprintf(pathname4, "%s", argv[4]);
	strcat(pathname4, "JOIN");
	file4 = open(pathname4,O_RDWR|O_TRUNC|O_CREAT,0666);
	writePhaseTimes(quantaJOIN, file4,maxTime);
	close(file4);

	printf("Finish~! \n");


}

