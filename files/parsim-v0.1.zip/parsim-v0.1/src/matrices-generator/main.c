/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * main.c
 * Copyright (C) 2013-2014 Andrea Rosà <andrea.rosa@usi.ch>
	 * 
 * matrix-generator is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
	 * 
 * matrix-generator is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even sthe implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

 /*  Parameters of main function:
 *	 argv[1]: desired filename for first matrix A
 *	 argv[2]: desired filename for second matrix B
 *	 argv[3]: number of rows for first matrix A
 *	 argv[4]: number of columns for first matrix A (equal to number of rows for second matrix B)
 *	 argv[5]: number of columns for second matrix B
 *	 argv[6]: minimum range for generated numbers
 *	 argv[7]: maximum range for generated numbers				 
 */

#include <stdio.h>
#include "mt64.h"
#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

  
 long long int generateMatrix(int matrix,long long int rows,long long int columns, double MIN, double MAX) {

	 double * temp = malloc(sizeof(double));
	 *temp = (double) columns;
	 write(matrix,temp,sizeof(double)); //The first field of the matrix structure contains the number of its columns

	 long long int i,j;


	 for (i = 0; i < rows; i++)
		 for (j = 0; j < columns; j++)
	 { *temp = (MAX-MIN)*genrand64_real1() + MIN;	
		 write(matrix,temp,sizeof(double));

	 }

	 free(temp);

	 return rows*columns;

 }
 
 int main(int argc, char **argv)
 {

	 errno = 0;  //Because strtoll can return negative value

	 if (argc != 8) {
		 printf("Error! Missing or useless parameters were passed");
		 return(-1);
	 }

	 long long int m = strtoll(argv[3],NULL,10);
	 if (errno != 0 || m <=0) {
		 printf("The number of rows of the first matrix is invalid\n");
		 return(-1);
	 }

	 long long int p = strtoll(argv[4],NULL,10);
	 if (errno != 0 || p <=0) {
		 printf("The number of columns of the first matrix (equal to the number of rows of the second matrix) is invalid\n");
		 return(-1);
	 }
	 long long int n = strtoll(argv[5],NULL,10);
	 if (errno != 0 || n <=0) {
		 printf("The number of columns of the second matrix is invalid\n");
		 return(-1);
	 }

	 double MIN = strtod(argv[6],NULL);
	 if (errno != 0 ) {
		 printf("The minimum range of numbers to generate is invalid\n");
		 return(-1);
	 }

	 double MAX = strtod(argv[7],NULL);
	 if (errno != 0 ) {
		 printf("The maximum range of numbers to generate is invalid\n");
		 return(-1);
	 }

	 //Initialization of the random number generator. For more informations see file "mt-19937-64.c"
	 init_genrand64((unsigned long long) getpid());


	 int a = open(argv[1],O_WRONLY|O_CREAT|O_TRUNC,0666);
	 int b = open(argv[2],O_WRONLY|O_CREAT|O_TRUNC,0666);

	 long long int num = generateMatrix(a,m,p, MIN, MAX);
	 printf("First matrix generated. Number of elements: %ld\n",num);

	 num = generateMatrix(b,p,n, MIN, MAX);
	 printf("Second matrix generated. Number of elements: %ld\n",num);

	 
	close(a); 
	close(b);

	return (0);
}

